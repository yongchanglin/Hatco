/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : include_h.h
  * @brief          : Header for all c files and h files.
  * @engineer       : lyc
  ******************************************************************************
  * @attention
  *
  * This file contains the common h file name which being used .
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _INCLUDE_H_H
#define _INCLUDE_H_H


//MCU
#include "stm32f4xx_it.h"
#include "main.h"
#include "stm32f4xx_hal_spi.h"



//#define	USE_RT_THREAD_OS	1

#if USE_RT_THREAD_OS == 1
	//rt-thread OS
	#include "rtconfig.h"
	#include "rtthread.h"
	#include "rtdebug.h"
	#include "rtdef.h"
	#include "rtservice.h"
	#include "rthw.h"

	//FreeRTOS
	//#include "cmsis_os.h"

	//user
	//#include "app_rt_thread.h"



#endif




#include "user.h"
#include "user_define.h"
#include "led.h"


#include "LCDConf.h"
//#include "GUI.h"
#include "lcdtft024.h"
#include "ILI9341_DRV.h"

#include "string.h"	//memcpy、memset函数的头文件为"string.h"
//malloc、free函数的头文件为"stdlib.h"





/*! 
*  \brief  macro define
*/

//extern UART_HandleTypeDef huart1;



/**
  * @}
*/ 

#endif /* _INCLUDE_H_H */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/

