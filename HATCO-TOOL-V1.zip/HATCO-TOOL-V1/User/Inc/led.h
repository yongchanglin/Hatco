/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : led.h
  * @brief          : Header for all user led.c file.
  * @engineer       : lyc
  ******************************************************************************
  * @attention
  *
  * This file contains the common defines of user led.c file.
  * nixie tube and indicator light
  *
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LED_H
#define __LED_H

/* Includes h files */
#include "include_h.h"


/*! 
*  \brief  macro define
*/
//IO
//#define  SEG_OUT	(uint16_t)GPIOA->ODR	
#define  SEG_OUT	GPIOA->ODR

#define  SEG_NULL	0xFFFF
#define  SEG_ALL	0x0000
#define  SEG_Dp		0xF7FF

/*
#define	SEG_b  0xFF03;
#define	SEG_c  0xFF27;
#define	SEG_d  0xFF21;
#define	SEG_r  0xEF7F;
#define	SEG_t  0xEF3F;
#define	SEG_o  0xFF23;
#define	SEG_y  0xEAFF;
#define	SEG_i  0xEDFF;
#define	SEG_k  0xE1FF;
#define	SEG_n  0xFF2B;
#define	SEG_l  0xFF2B;
*/
#define	SEG_A  0xFEC8
/*
#define	SEG_B  0xED70;
#define	SEG_C  0xFFC6;
#define	SEG_D  0xEDF0;
#define	SEG_E  0xFF06;
#define	SEG_F  0xFF0E;
#define	SEG_G  0xFF42;
#define	SEG_H  0xFF09;
#define	SEG_I  0xEDF6;
#define	SEG_L  0xFFC7;
#define	SEG_M  0xFAC9;
#define	SEG_N  0xF6C9;
#define	SEG_O  0xFFC0;
#define	SEG_Q  0xF7C0;
#define	SEG_R  0xF70C;
#define	SEG_S  0xFF12;
#define	SEG_T  0xEDFE;
#define	SEG_U  0xFFC1;
#define	SEG_V  0xF6F9;
#define	SEG_W  0xD7C9;
#define	SEG_X  0xD2FF;
#define	SEG_Y  0xFF11;
*/

/*! 
*  \brief  variable definition, extern
*  \param
*/
extern	uint16_t	u16SegData[2];





/*! 
*  \brief  extern function
*  \param
*/
extern	void UI_Display(void);
extern	void NixieTube_Drive(void);



/**
  * @}
*/ 

#endif /* __LED_H */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/

