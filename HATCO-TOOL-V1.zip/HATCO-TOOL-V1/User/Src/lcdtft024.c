/*
 * ******************************************************************************
 * lcd.c
 *
 *  Created on: Sep 9, 2022
 *      Author: lyc
 *		 Brief: TFT-LCD
 *
 * ******************************************************************************
 * attention:
 *
 * MCU: STM32F401RC
 * TFT-LCD: ER-TFT024-3 ， ILI9341
 *
 *
 * ******************************************************************************
 */
/* USER CODE BEGIN Header */

/* Includes */
#include "include_h.h"

/*!
*  \brief  const definition
*  \param
*/
//extern GUI_CONST_STORAGE GUI_BITMAP bmlogo3;
extern GUI_CONST_STORAGE GUI_BITMAP bmNTC2;


/*!
*  \brief  variable definition
*  \param
*/
LCD_TypeDef		Lcd;

uint16_t	u16temp;
uint16_t	u16temp1;
char* 		chartemp;


/*!
*  \brief  Private function prototypes
*  \param
*/
//void LCD_WR_CMD(uint16_t DATA);
//void LCD_WR_DATA(uint16_t DATA);
//void LCD_RD_DATA(uint16_t DATA);
void LCD_WR_CMD(uint8_t DATA);
void LCD_WR_DATA(uint8_t DATA);
uint8_t LCD_RD_DATA(uint8_t DATA);
void LCD_RESET(void);
void LCD_Init(void);
void GUI_PowerOn_Dis(void);
void GUI_Handle(void);


/*!
*   \brief  variables-init
*   \param
*/
/*
static void _swap(uint16_t *a, uint16_t *b)
{
    uint16_t temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
*/


/*!
*  \brief 	LCD SPI write command
*  \param
*/
//void LCD_WR_CMD(uint16_t DATA)
void LCD_WR_CMD(uint8_t DATA)
{
	uint16_t retry=0;
	//LCD_CS_CLR;
	LCD_WRX_CLR;
	while ((SPI1->SR & SPI_FLAG_TXE) == 0)
	{
		retry++;
		if(retry>=0XFF)	return ;		// 0; 	//TIME-OUT
	}
	SPI1->DR = DATA;	 	  		//*((__IO uint8_t *)&SPI1->DR) = data;
	//LCD_CS_SET;
}
/*!
*  \brief 	LCD SPI write data
*  \param
*/
//void LCD_WR_DATA(uint16_t DATA)
void LCD_WR_DATA(uint8_t DATA)
{
	uint16_t retry=0;
	//LCD_CS_CLR;
	LCD_WRX_SET;
	while ((SPI1->SR & SPI_FLAG_TXE) == 0)
	{
		retry++;
		if(retry>=0XFF)	return ;		// 0; 	//TIME-OUT
	}
	SPI1->DR = DATA;	 	  		//*((__IO uint8_t *)&SPI1->DR) = data;
	//LCD_CS_SET;
}

/*!
*  \brief 	LCD SPI read data
*  \param
*/
//void LCD_RD_DATA(uint16_t DATA)
uint8_t LCD_RD_DATA(uint8_t DATA)
{
	HAL_SPI_Receive(&hspi1, (uint8_t*)&DATA, 1, 0xffff);
	return DATA = SPI_ReadByteQuick(DATA);
}

/*!
*  \brief 	LCD reset
*  \param
*/
void LCD_RESET(void)
{
	LCD_RST_CLR;
	LCD_BACK_OFF;
	HAL_Delay(100);//osDelay(100);//HAL_Delay(100);
	LCD_RST_SET;
	LCD_BACK_ON;
	LCD_NSS_ENA;

    SPI1->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
    SPI1->CR1 &= ~SPI_CR1_DFF; // SPI 8		//SPI_MASTER->CR1 |= SPI_CR1_DFF;  // SPI 16
    SPI1->CR1 |= SPI_CR1_SPE;  // ENABLE SPI

    HAL_Delay(50);//osDelay(50);//HAL_Delay(50);
}
/*!
*  \brief LCD_Init_ILI9341
*  \param SPI
*/
void LCD_Init(void)
{
	LCD_RESET();

	LCD_WR_CMD(0xCF);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0xc3);//
	LCD_WR_DATA(0X30);

 	LCD_WR_CMD(0xED);
	LCD_WR_DATA(0x64);
	LCD_WR_DATA(0x03);
	LCD_WR_DATA(0X12);
	LCD_WR_DATA(0X81);

 	LCD_WR_CMD(0xE8);
	LCD_WR_DATA(0x85);
	LCD_WR_DATA(0x10);
	LCD_WR_DATA(0x79);//

 	LCD_WR_CMD(0xCB);
	LCD_WR_DATA(0x39);
	LCD_WR_DATA(0x2C);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x34);
	LCD_WR_DATA(0x02);

 	LCD_WR_CMD(0xF7);
	LCD_WR_DATA(0x20);

 	LCD_WR_CMD(0xEA);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x00);

 	LCD_WR_CMD(0xC0);    //Power control
	LCD_WR_DATA(0x22);   //VRH[5:0]

 	LCD_WR_CMD(0xC1);    //Power control
	LCD_WR_DATA(0x11);   //SAP[2:0];BT[3:0]

 	LCD_WR_CMD(0xC5);    //VCM control
	LCD_WR_DATA(0x3d);
    //LCD_DataWrite_ILI9341(0x30);
	LCD_WR_DATA(0x20);

 	LCD_WR_CMD(0xC7);    //VCM control2
    //LCD_DataWrite_ILI9341(0xBD);
	LCD_WR_DATA(0xAA); //0xB0

 	LCD_WR_CMD(0x36);    // Memory Access Control
	LCD_WR_DATA(0x08);

 	LCD_WR_CMD(0x3A);
	LCD_WR_DATA(0x55);

 	LCD_WR_CMD(0xB1);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x13);//

 	LCD_WR_CMD(0xB6);    // Display Function Control
	LCD_WR_DATA(0x0A);
	LCD_WR_DATA(0xA2);

 	LCD_WR_CMD(0xF6);
	LCD_WR_DATA(0x01);
	LCD_WR_DATA(0x30);

 	LCD_WR_CMD(0xF2);    // 3Gamma Function Disable
	LCD_WR_DATA(0x00);

 	LCD_WR_CMD(0x26);    //Gamma curve selected
	LCD_WR_DATA(0x01);

 	LCD_WR_CMD(0xE0);    //Set Gamma
	LCD_WR_DATA(0x0F);
	LCD_WR_DATA(0x3F);
	LCD_WR_DATA(0x2F);
	LCD_WR_DATA(0x0C);
	LCD_WR_DATA(0x10);
	LCD_WR_DATA(0x0A);
	LCD_WR_DATA(0x53);
	LCD_WR_DATA(0XD5);
	LCD_WR_DATA(0x40);
	LCD_WR_DATA(0x0A);
	LCD_WR_DATA(0x13);
	LCD_WR_DATA(0x03);
	LCD_WR_DATA(0x08);
	LCD_WR_DATA(0x03);
	LCD_WR_DATA(0x00);

 	LCD_WR_CMD(0XE1);    //Set Gamma
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0x10);
	LCD_WR_DATA(0x03);
	LCD_WR_DATA(0x0F);
	LCD_WR_DATA(0x05);
	LCD_WR_DATA(0x2C);
	LCD_WR_DATA(0xA2);
	LCD_WR_DATA(0x3F);
	LCD_WR_DATA(0x05);
	LCD_WR_DATA(0x0E);
	LCD_WR_DATA(0x0C);
	LCD_WR_DATA(0x37);
	LCD_WR_DATA(0x3C);
	LCD_WR_DATA(0x0F);

 	LCD_WR_CMD(0x11);    //Exit Sleep
 	osDelay(120);//HAL_Delay(120);
 	LCD_WR_CMD(0x29);    //Display on
 	osDelay(50);//HAL_Delay(50);

}

/*!
*  \brief LCD_Handle/GUI_Handle
*  \param SPI, DMA transform
*/
void GUI_PowerOn_Dis(void)
{
	//display HATCO logo
	GUI_Init();

	GUI_SetBkColor(GUI_GREEN);	//GUI_DARKGREEN
	GUI_Clear();
	GUI_SetColor(GUI_RED);	//GUI_BLACK
	GUI_SetFont(&GUI_Font24B_ASCII);	//GUI_Font32B_ASCII
	//GUI_DrawBitmap(&bmlogo3,0,0);
	GUI_DispStringHCenterAt("TOOL_V0001C",120,300);//GUI_DispStringAt("TOOL_V0001",50,300);

	Delay.u8T100ms_PowerOn = 0;
}

/*!
*  \brief LCD_Handle/GUI_Handle
*  \param SPI, DMA transform
*/
void GUI_Handle(void)
{
	//100MS refresh
	if(Sys.u8power == 1)
	{

	#ifdef	TEST_DISPLAY_TIME

		Delay.u16T1ms_GUI_1 = 0;
		GUI_DispStringAt("Hello Hatco",50,50);
		GUI_DispStringAt("NTC1: XX C",50,85);
		//GUI_DispDec(u16temp,5);
		GUI_DispDecAt(u16temp1,100,110,5);		//u16temp1

		GUI_DrawLine(10,10,200,10);
		chartemp = (char*)GUI_GetVersionString();
		GUI_DispStringAt(chartemp,15,15);

		u16temp = Delay.u16T1ms_GUI_1;
		GUI_DispDecAt(u16temp,100,140,5);

		Delay.u16T1ms_GUI_3 = 0;
		GUI_SetColor(GUI_BLUE);
		//GUI_Clear();
		GUI_DrawLine(10,250,200,250);

		GUI_SetTextMode(GUI_TM_TRANS);
		GUI_DispStringHCenterAt("NTC2: XXF XXC",120,200);

		u16temp = Delay.u16T1ms_GUI_3;
		GUI_DispDecAt(u16temp,100,165,5);
		GUI_DispDecSpace(u16temp,5);

		osDelay(2000);//HAL_Delay(2000);

		Delay.u16T1ms_GUI_2 = 0;
		//GUI_SetBkColor(GUI_YELLOW);
		//GUI_DrawBitmap(&bmlogo3,0,0);
		u16temp1 = Delay.u16T1ms_GUI_2;

		osDelay(1500);//HAL_Delay(1500);

		GUI_Clear();
		GUI_SetColor(GUI_RED);
	#endif


		if(Delay.u8T10ms_LCD >= 10)		//100MS
		{
			Delay.u8T10ms_LCD = 0;

			GUI_DrawBitmap(&bmNTC2,0,0);

			//u16temp = Delay.u16T1ms_GUI_3;
			GUI_DispDecAt(u16temp,100,165,5);
			GUI_DispDecSpace(u16temp,5);

		}
	}
	else
	{
		Delay.u8T10ms_LCD = 0;

		if(Delay.u8T100ms_PowerOn >= 20)	Sys.u8power = 1;

	}
}





/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
