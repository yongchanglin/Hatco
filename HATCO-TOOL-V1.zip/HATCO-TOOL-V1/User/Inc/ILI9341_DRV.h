/*
 * lcd.h
 *
 *  Created on: Sep 9, 2022
 *      Author: Administrator
 */

#ifndef INC_ILI9341_DRV_H_
#define INC_ILI9341_DRV_H_

/* Includes h files */
#include "include_h.h"



/*!
*  \brief  type define
*/
/* Macro to get variable aligned on 32-bytes,needed for cache maintenance purpose */
#if defined   (__GNUC__)        /* GNU Compiler */
  #define ALIGN_32BYTES(buf)  buf __attribute__ ((aligned (32)))
#elif defined (__ICCARM__)    /* IAR Compiler */
  #define ALIGN_32BYTES(buf) _Pragma("data_alignment=32") buf
#elif defined   (__CC_ARM)      /* ARM Compiler */
  #define ALIGN_32BYTES(buf) __align(32) buf
#endif


/*!
*  \brief  macro define
*/

#define SPI1_BUFFER_SIZE (4 * 1024)


#define TFTSPI 			SPI1 //TFT的SPI
#define TFTDMA 			DMA2_Stream3 //TFT SPI的DMA
#define TFTDMAHandle 	hdma_spi1_tx

#define LCD_Width	 	240
#define LCD_Height	 	320



/*!
*  \brief  variable definition
*  \param
*/
static __IO uint32_t  dummy=0;

#if LCD_Width > LCD_Height    //SPI DMA最多一次写5行的数据。 可以适当节约RAM占用。SPI模式下，每个点需要3个字节。
#define POINT_NUM 	(LCD_Width*5)
#else
#define POINT_NUM 	(LCD_Height*5)
#endif




/*!
*  \brief  variable definition, extern
*  \param
*/
//extern  LCD_TypeDef		Lcd;

//extern uint8_t u8SpiDmaTxBuf[0xffff];



/*!
*  \brief  extern function
*  \param
*/
extern void LCD_SPI_Init(void);
extern void SPI_SendByteQuick(uint8_t data);
extern uint8_t SPI_ReadByteQuick(uint8_t data);

extern void bsp_SpiSendBuf(SPI_TypeDef *_spi, const char *_txbuf, uint32_t _txlen);
extern void TFTSPI_DMA_WriteData(uint16_t num);




/**
  * @}
*/


#endif /* INC_ILI9341_DRV_H_ */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
