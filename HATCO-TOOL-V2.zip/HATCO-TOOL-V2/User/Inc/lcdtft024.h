/*
 * lcd.h
 *
 *  Created on: Sep 9, 2022
 *      Author: Administrator
 */

#ifndef INC_LCDTFT024_H_
#define INC_LCDTFT024_H_

/* Includes h files */
#include "include_h.h"



/*!
*  \brief  DAC type define
*/
typedef struct
{
	//uint8_t		u8EncoderData;	//0 ~ 70 ==> 0v~3.3V
	//uint16_t 	u16Count;		//0 ~ 70
	//uint16_t	u16SPI1_RXBuff[1];		//
	//uint16_t	u16SPI1_TxBuff[1];		//

	uint8_t		u8MenuLayer;
	uint8_t		u8MenuLayer_Dis;


}LCD_TypeDef;

/*!
*  \brief  macro define
*/
//*LCD-Menu_Layer */
#define		MENU_LAYER_LOGO			0
#define		MENU_LAYER_NTC			1


//*NTC-resistor-display-digit */
#define		RT_DIGITS				8		//100K
#define		RT_DECIMAL_PLACES		3		//decimal places:3
#define		RT_DIS_ORIGIN			130		//240*320

//COLOR BAR	//240*320
#define		BAR_X_START				0		//240*320
#define		BAR_X_END				240		//240*320

#define		BAR_DESC_Y_START		0		//
#define		BAR_DESC_Y_END			29		//
#define		BAR_LABEL_1_Y_START		30		//
#define		BAR_LABEL_1_Y_END		59		//
#define		BAR_LABEL_2_Y_START		60		//
#define		BAR_LABEL_2_Y_END		89		//





/*
GUI_CONST_STORAGE GUI_BITMAP bmlogo = {
	240,
	320,
	480,
	16,
	(unsigned char *)gImage_logo2,
	NULL,
	GUI_DRAW_BMP565
};
*/

/*!
*  \brief  variable definition, extern
*  \param
*/
extern  LCD_TypeDef		Lcd;


/*!
*  \brief  extern function
*  \param
*/
//extern void LCD_WR_CMD(uint16_t DATA);
//extern void LCD_WR_DATA(uint16_t DATA);
//extern void LCD_RD_DATA(uint16_t DATA);
extern void LCD_WR_CMD(uint8_t DATA);
extern void LCD_WR_DATA(uint8_t DATA);
extern uint8_t LCD_RD_DATA(uint8_t DATA);

extern void LCD_Init(void);
extern void GUI_PowerOn_Dis(void);
extern void GUI_Handle(void);


/**
  * @}
*/

#endif /* INC_LCDTFT024_H_ */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
