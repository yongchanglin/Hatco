/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file      led.c
 * @author    lyc
 * @brief     nixie tube and indicator light
 *
 *
 ******************************************************************************
 * @attention
 *
 * based on STM32F030C8 -- SRAM:8K ,FLASH:64K
 * logic: 分时扫描驱动，1ms驱动一组，共7组一个周期
 *
 *
 *
 ******************************************************************************
 */

/* Includes */
#include "include_h.h"

/*! 
*  \brief  const definition
*/
uint16_t const	SEG_NUMBER[10] = {	// 0      1     2      3      4       
									0xFFC0,0xFFF9,0xFEE4,0xFEF0,0xFED9,
									// 5      6      7      8     9           
									0xFED2,0xFEC2,0xFFF8,0xFEC0,0xFED0
								 };
/*! 
*  \brief  variable definition
*/

uint16_t	u16SegData[2]={0xFFFF,0xFFFF};



/*!
*  \brief  Private function prototypes
*  \param
*/
void UI_PowerOn_Display(void);



/*!
*   \brief  variables-init
*   \param  
*/
/*!
*  \brief UI_PowerOn_Display
*  \param
*/
void UI_PowerOn_Display(void)
{

	if(Sys.u8power_flow == 0)
	{
		u16SegData[0]= SEG_ALL;
		u16SegData[1]= SEG_ALL;
		Sys.u8power_flow = 1;
		Delay.u16T10ms_Display = 0;
	}
	else if(Sys.u8power_flow == 1)
	{
		if(Delay.u16T10ms_Display >= TIME10MS_800MS)
		{
			Sys.u8power_flow = 2;
			//Delay.u16T10ms_Display = 0;
			//UI software version -- UI A1
			u16SegData[0]= (SEG_A & SEG_Dp);
			u16SegData[1]= SEG_NUMBER[0];
		}
	}
	else if(Sys.u8power_flow == 2)
	{
		if(Delay.u16T10ms_Display >= TIME10MS_3S)
		{
			Sys.u8power = 1;
			Delay.u16T10ms_Display = 0;
			Sys.u8power_flow = 3;


			//默认或者上次记忆值
			u16SegData[0]= (SEG_NUMBER[1] & SEG_Dp);
			u16SegData[1]= SEG_NUMBER[2];






		}
	}
}


/*!
*  \brief UI_USER_DATA_Display
*  \param
*/
void UI_USER_DATA_Display(void)
{
/*
	if(u8Time100ms_UserData >= 50)
	{
		//Sys.u8UserData_flow = 0;
	}
	else
	{
		u16SegData[0]= SEG_NUMBER[2];
		u16SegData[1]= SEG_NUMBER[3];

	}
*/
}

/*! 
*  \brief UI display
*  \param 
*/
void UI_Display(void)
{


	if(Sys.u8power == 1)
	{


	}
	else	//上电过程初始化显示
	{
		UI_PowerOn_Display();

	}
}



/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
