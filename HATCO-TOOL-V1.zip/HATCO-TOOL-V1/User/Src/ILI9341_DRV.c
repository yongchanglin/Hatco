/*
 * ******************************************************************************
 * lcd.c
 *
 *  Created on: Sep 9, 2022
 *      Author: lyc
 *		 Brief: TFT-LCD
 *
 * ******************************************************************************
 * attention:
 *
 * MCU: STM32F401RC
 * TFT-LCD: ER-TFT024-3 ， ILI9341
 *
 *
 * ******************************************************************************
 */
/* USER CODE BEGIN Header */

/* Includes */
#include "include_h.h"

/*!
*  \brief  const definition
*  \param
*/


/*
#define GUI_NUMBYTES	20*1024  		//0x200000 set EMWIN memory size
#define GUI_BLOCKSIZE	0x80			//block size
uint8_t spidatabuf[GUI_NUMBYTES/4];//SPI DMA的数据缓存区。最大5行数据的缓冲区。占用320x5x2=7.2KB
*/

//uint8_t u8SpiDmaTxBuf[0xff];	//[0xffff];


/*!
*  \brief  Private function prototypes
*  \param
*/
void LCD_SPI_Init(void);
void SPI_SendByteQuick(uint8_t data);
uint8_t SPI_ReadByteQuick(uint8_t data);

void bsp_SpiSendBuf(SPI_TypeDef *_spi, const char *_txbuf, uint32_t _txlen);
void TFTSPI_DMA_WriteData(uint16_t num);


/*!
*  \brief  variable definition
*  \param
*/
//LCD_TypeDef		Lcd;


/*!
*  \brief  Private function prototypes
*  \param
*/



/*!
*  \brief  LCD_SPI_Init
*  \param  // 硬件模式 /// 优化代码，快速操作 //
*/
void LCD_SPI_Init(void)
{
    //SPI--REGISTER
	SPI1->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
    SPI1->CR1 &= ~SPI_CR1_DFF; // SPI 8	 //SPI_MASTER->CR1 |= SPI_CR1_DFF; // SPI 16
    SPI1->CR1 |= SPI_CR1_SPE;  // ENABLE SPI

    //SPI--DMA
    //TFTDMA->PAR  = (uint32_t)&TFTSPI->DR;  	//
    //TFTDMA->M0AR = (uint32_t)u8SpiDmaTxBuf;  //DMA TX BUFFER
}

/*!
*  \brief  SPI_SendByteQuick
*  \param  // 硬件模式 /// 优化代码，快速操作 //
*/
void SPI_SendByteQuick(uint8_t data)
{
	uint16_t retry=0;
	/*
    SPI1->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
    SPI1->CR1 &= ~SPI_CR1_DFF; // SPI 8		//SPI_MASTER->CR1 |= SPI_CR1_DFF;  // SPI 16
    SPI1->CR1 |= SPI_CR1_SPE;  // ENABLE SPI
	 */
    while ((SPI1->SR & SPI_FLAG_TXE) == 0)
    {
		retry++;
		if(retry>=0XFF)	return ;		// 0; 	//TIME-OUT
	}
    SPI1->DR = data;	 	  		//*((__IO uint8_t *)&SPI1->DR) = data;
}
/*!
*  \brief  SPI_ReadByteQuick
*  \param  // 硬件模式 /// 优化代码，快速操作 //
*/
uint8_t SPI_ReadByteQuick(uint8_t data)
{
	uint16_t retry=0;

    SPI1->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
    SPI1->CR1 &= ~SPI_CR1_DFF; // SPI 8		//SPI_MASTER->CR1 |= SPI_CR1_DFF;  // SPI 16
    SPI1->CR1 |= SPI_CR1_SPE;  // ENABLE SPI

	while((SPI1->SR & SPI_FLAG_RXNE)==0) 		//
	{
		retry++;
		if(retry>=0XFF)
			return data = SPI1->DR;	//
	}
	return data = SPI1->DR;
}
/*
uint8_t SPI_WriteReadByte(SPI_TypeDef* SPIx,uint8_t Byte)
{

    while((SPIx->SR&SPI_FLAG_TXE)==RESET);		//等待发送区空
    SPIx->DR=Byte;	 	//发送一个字节
    while((SPIx->SR&SPI_FLAG_RXNE)==RESET);//等待接收一个字节
    return SPIx->DR;          	     //返回接收到的数据。
//  return 1;
}
*/
//void TFTSPI_DMA_WriteData(uint8_t *a, uint16_t num)
void TFTSPI_DMA_WriteData( uint16_t num)
{
	//TFTDMA->PAR  = (uint32_t)&TFTSPI->DR;  	//
	//TFTDMA->M0AR = (uint32_t)pData;  //DMA TX BUFFER

    TFTDMA->CR  &= (uint32_t)(~DMA_SxCR_DBM);
    TFTDMA->NDTR = num;	//(uint16_t)NumItems;	//num;	//PAR和M0AR 在LCD的GPIO初始化中了。
    TFTDMA->CR  |= DMA_SxCR_EN;		//hdma_spiX_tx DMA enable

    SET_BIT(TFTSPI->CR2, SPI_CR2_TXDMAEN);

    while(__HAL_DMA_GET_FLAG(&TFTDMAHandle,DMA_FLAG_TCIF3_7)==0) __NOP();//由于没有DMA中断，这里必须查询后主动清零。
    __HAL_DMA_CLEAR_FLAG(&TFTDMAHandle,DMA_FLAG_TCIF3_7);	//

    while(TFTSPI->SR & SPI_FLAG_BSY) __NOP();	//此语句必须配合使用。 保证最后一个字节发送完成。
    CLEAR_BIT(TFTSPI->CR2, SPI_CR2_TXDMAEN);

    TFTDMA->CR &=  ~DMA_SxCR_EN;		//hdma_spiX_tx DMA disable
/*
    while((TFTSPI->SR&SPI_FLAG_RXNE)== 0) __NOP();
    dummy = TFTSPI->DR; 	//清除OVR标记。
    dummy = TFTSPI->SR;
*/
}

/*!
*  \brief 	ILI9341_DrawPixelGUI
*  \param
*/
/*
void ILI9341_DrawPixelGUI(xPhys,yPhys,PixelIndex)	//打点函数
{

}
*/


/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
