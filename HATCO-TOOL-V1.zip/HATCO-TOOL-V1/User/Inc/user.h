/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : user.h
  * @brief          : Header for user.c file.
  * @engineer       : lyc
  ******************************************************************************
  * @attention
  *
  * This file contains the common defines of user.c file.
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USER_H
#define __USER_H

/* Includes h files */
#include "include_h.h"


//*UI-version*/
#define		VERSION_UI		A0
//Description:
//
//
//22-09-08:A0 ，new design for TM3
//

//#define		TEST_DISPLAY_TIME		1



/*! 
*  \brief  type define
*/
//*system-sate*/
typedef struct
{

	uint8_t		u8power;		//上电
	uint8_t		u8power_flow;	//
	uint8_t		u8state;		//状态 standby/hold/retherm

	/*
//	uint8_t		u8mode;			//temp/type
//	uint8_t		u8menu_flow;	//menu set flow
	uint8_t		u8time;			//10min~255minutes
	uint8_t		u8time_flow;	//
	uint8_t		u8time_flag;	// 1:count down on  ; 0:off
	uint8_t		u8lock;			//按键锁定
//	uint8_t		u8AutomaticWater;			//
//	uint8_t		u8UserData_flow;	//
//	uint8_t		u8alarm;
	
//	uint8_t		u8NTC;			//NTC
//	uint8_t		u8PT100;		//PT100
//	uint8_t		u8MB;			//main board
	
*/
}SYSTEM_TypeDef;

/*!
*  \brief  DELAY type define
*/
typedef struct
{
	uint8_t		u8T1ms_SysTick;
	uint16_t 	u16T1ms_GUI_1;
	uint16_t 	u16T1ms_GUI_2;
	uint16_t 	u16T1ms_GUI_3;

	uint8_t		u8T10ms;
	uint16_t 	u16T100ms;
	uint16_t 	u16T60s;

	uint8_t		u8T100ms_PowerOn;

	uint16_t	u16T10ms_Key;
	uint16_t	u16T10ms_Display;
	uint8_t		u8T10ms_LCD;


}DELAY_TypeDef;

/*! 
*  \brief  macro define
*/

//*system-sate*/
#define		SYS_STANDBY		0x00
#define		SYS_HOLD		0x03
#define		SYS_HEAT		0x04	//SYS_RETHERM
#define		SYS_ALARM		0x05


//*system-mode - type*/
//#define		MODE_MAX		0x11
//#define		MODE_BROTH		0x12

//#define		MODE_TEMP		0x16

//*IO-Port*/

//



/*! 
*  \brief  variable definition, extern
*  \param
*/
extern  SYSTEM_TypeDef	Sys;
extern  DELAY_TypeDef 	Delay;


/*
extern	uint8_t u8ToggleFlag;
extern	uint8_t u8Time1ms;
extern	uint8_t	u8Time10ms;
extern	uint16_t u16Time100ms;
//extern	uint16_t u16Time100ms_old;
extern	uint16_t u16Time60s;
*/

//*CONTROL*/





/*! 
*  \brief  extern function
*  \param
*/

extern void User_System_Init(void);
extern void Variables_Init(void);
//extern void CMD_UART1(void);

extern void TIME_BASE_Callback(void);
extern void NTC_Test(void);


/**
  * @}
*/ 

#endif /* __user_H */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/

