/*
 * lcd.h
 *
 *  Created on: Sep 9, 2022
 *      Author: Administrator
 */

#ifndef INC_LCDTFT024_H_
#define INC_LCDTFT024_H_

/* Includes h files */
#include "include_h.h"



/*!
*  \brief  DAC type define
*/
typedef struct
{
	uint8_t		u8EncoderData;	//0 ~ 70 ==> 0v~3.3V
	//uint16_t 	u16Count;		//0 ~ 70
	uint16_t	u16SPI1_RXBuff[1];		//
	uint16_t	u16SPI1_TxBuff[1];		//



}LCD_TypeDef;

/*!
*  \brief  macro define
*/

//#define		DAC5571_ADDRESS			0x98



/*
GUI_CONST_STORAGE GUI_BITMAP bmlogo = {
	240,
	320,
	480,
	16,
	(unsigned char *)gImage_logo2,
	NULL,
	GUI_DRAW_BMP565
};
*/

/*!
*  \brief  variable definition, extern
*  \param
*/
extern  LCD_TypeDef		Lcd;


/*!
*  \brief  extern function
*  \param
*/
//extern void LCD_WR_CMD(uint16_t DATA);
//extern void LCD_WR_DATA(uint16_t DATA);
//extern void LCD_RD_DATA(uint16_t DATA);
extern void LCD_WR_CMD(uint8_t DATA);
extern void LCD_WR_DATA(uint8_t DATA);
extern uint8_t LCD_RD_DATA(uint8_t DATA);

extern void LCD_Init(void);
extern void GUI_PowerOn_Dis(void);
extern void GUI_Handle(void);


/**
  * @}
*/

#endif /* INC_LCDTFT024_H_ */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
