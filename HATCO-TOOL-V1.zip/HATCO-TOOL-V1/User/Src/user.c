/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file      user.c
 * @author    lyc
 * @brief     user control logic
 *
 *
 ******************************************************************************
 * @attention
 *
 * based on STM32F030C8
 *
 *
 ******************************************************************************
 */

/* Includes */
#include "include_h.h"


/*! 
*  \brief  variable definition
*  \param  
*/
SYSTEM_TypeDef	Sys;
DELAY_TypeDef 	Delay;

extern volatile GUI_TIMER_TIME OS_TimeMS;


/*!
*  \brief  Private function prototypes
*  \param
*/
void User_System_Init(void);
void Variables_Init(void);
void TIME_BASE_Callback(void);
void NTC_Test(void);




/*!
*   \brief  variables-init
*   \param  
*/
void Variables_Init(void)
{
	Sys.u8state = SYS_STANDBY;	//SYS_ALARM  SYS_STANDBY
	Sys.u8power = 0;
	Sys.u8power_flow = 0;

	Delay.u8T1ms_SysTick = 0;
	Delay.u16T10ms_Key = 0;
	Delay.u8T10ms_LCD = 0;



	//logo
}

/*!
*   \brief  system-init
*   \param  I/O,
*/
void User_System_Init(void)
{
	BEEP_OFF;	//BEEP_ON;
	//HAL_Delay(10);
	Variables_Init();

	GUI_PowerOn_Dis();

	//HAL_ADC_Start_DMA(&hadc1, (uint32_t *)&KeyADC.u32ADC_DMA, 16);

}

/*! 
*  \brief SYSTick IRQ callback / TIME base
*  \param system-stick 1ms
*/
//void HAL_SYSTICK_Callback(void)
void TIME_BASE_Callback(void)
{
	Delay.u8T1ms_SysTick ++;	//1ms
	OS_TimeMS ++;

	Delay.u16T1ms_GUI_1 ++;	//1ms
	Delay.u16T1ms_GUI_2 ++;	//1ms
	Delay.u16T1ms_GUI_3 ++;	//1ms

	//LCD_BACK_TOGGLE;

	if(Delay.u8T1ms_SysTick >= TIME1MS_10MS)	//10ms
	{
		Delay.u8T1ms_SysTick = 0;
		Delay.u8T10ms ++;
		
		Delay.u16T10ms_Display ++;
		Delay.u16T10ms_Key ++;
		Delay.u8T10ms_LCD ++;
		
		if(Delay.u8T10ms >= TIME10MS_100MS)	//100ms
		{
			Delay.u8T10ms = 0;
			Delay.u16T100ms ++;

			Delay.u8T100ms_PowerOn ++;


			Delay.u16T60s ++;
			if(Delay.u16T60s >= 10)	//TIME100MS_60S,100ms*600 = 60s
			{
				Delay.u16T60s = 0;
				//time count down

			}
		}
	}
}

/*! 
*  \brief NTC_Test
*  \param ADC TEST 100ms
*/
void NTC_Test(void)
{/*
	uint8_t i,j;
	uint32_t	u32cal;

	HAL_ADC_Stop_DMA(&hadc1);

	KeyADC.u8Flag_ADC_DMA = 0;

	KeyADC.u8Key_Count = 0;		//delay
	DELAY_10_NOP;DELAY_10_NOP;

	HAL_ADC_Start_DMA(&hadc1, (uint32_t *)&KeyADC.u32ADC_DMA, 16);
	//HAL_DMA_IRQHandler(&hdma_adc1);
	DELAY_10_NOP;DELAY_10_NOP;

	while(KeyADC.u8Flag_ADC_DMA != 1);//while(__HAL_DMA_GET_FLAG(&hdma_adc1, __FLAG__));

	for(i=0;i<8;i++)	// 8  or 10
	{
		if(KeyADC.u32ADC_DMA[i] < HIGH_REISISTOR_LIMIT)	//key press
		{
			KeyADC.u8Key_Count ++;
			u8sum_chrl += i;
		/*	if(KeyADC.u8Key_Count>=3)	KeyADC.u8Key_Count = 3;
			if(j == 0)	{u8key_temp_count0[KeyADC.u8Key_Count-1] = i;}
			if(j == 1)	{u8key_temp_count1[KeyADC.u8Key_Count-1] = i;}
			if(j == 2)	{u8key_temp_count2[KeyADC.u8Key_Count-1] = i;}*/
/*
}
	}

	if(KeyADC.u8Key_Count >= 1)
	{
		//if(KeyADC.u8Key_Count >= 3)		KeyADC.u8Key_Count = 3;	//MAX 3 KEY
		KeyADC.u8Key_RC_Count = 0;
		for(i=0;i<16;i++)
		{
			HAL_ADC_Stop_DMA(&hadc1);

			KeyADC.u8Flag_ADC_DMA = 0;


			for(j=0;j<8;j++)	// 8  or 10
			{

			}
		}


	}

	Sys.u8AD_Scan_Flag = 0;
*/

}


/*!
*  \brief EXTI_GPIO IRQ callback
*  \param 
*/

/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/
