/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : include_h.h
  * @brief          : Header for all c files and h files.
  * @engineer       : lyc
  ******************************************************************************
  * @attention
  *
  * This file contains the common h file name which being used .
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _INCLUDE_H_H
#define _INCLUDE_H_H


//MCU
#include "stm32f4xx_it.h"
#include "main.h"
#include "stm32f4xx_hal_spi.h"

//OS
#include "cmsis_os.h"




#include "user.h"
#include "user_define.h"
#include "led.h"


#include "LCDConf.h"
#include "GUI.h"
#include "lcdtft024.h"
#include "ILI9341_DRV.h"

#include "string.h"	//memcpy、memset函数的头文件为"string.h"
//malloc、free函数的头文件为"stdlib.h"

/*! 
*  \brief  macro define
*/

//extern UART_HandleTypeDef huart1;



/**
  * @}
*/ 

#endif /* _INCLUDE_H_H */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/

