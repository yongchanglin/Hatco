/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : user_define.h
  * @brief          : Header for all c file.
  * @engineer       : lyc
  ******************************************************************************
  * @attention
  *
  * This file contains the common defines of the application.
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USER_DEFINE_H
#define __USER_DEFINE_H

/* Includes h files */
//#include "main.h"
#include "stm32f4xx_it.h"


/*! 
*  \brief  type define
*/
    /* exact-width signed integer types */
typedef   signed          char int8;
typedef   signed short     int int16;
typedef   signed           int int32;
//typedef   signed       __int64 int64;

    /* exact-width unsigned integer types */
typedef unsigned          char uint8;
typedef unsigned short     int uint16;
typedef unsigned           int uint32;
//typedef unsigned       __int64 uint64;

/*! 
*  \brief  time base macro define
*/
#define 	DELAY_5_NOP			__NOP();__NOP();__NOP();__NOP();__NOP()
#define 	DELAY_10_NOP		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP()
#define 	TIME1MS_10MS		10
#define 	TIME1MS_50MS		50
#define 	TIME1MS_80MS		80
#define 	TIME1MS_100MS		100
#define 	TIME10MS_50MS		5
#define 	TIME10MS_80MS		8
#define 	TIME10MS_100MS		10
#define 	TIME10MS_200MS		20
#define 	TIME10MS_500MS		50
#define 	TIME10MS_600MS		60
#define 	TIME10MS_800MS		80
#define 	TIME10MS_900MS		90
#define 	TIME10MS_1S			100
#define 	TIME10MS_1S05		105
#define 	TIME10MS_1S06		106
#define 	TIME10MS_1S1		110
#define 	TIME10MS_1S4		140
#define 	TIME10MS_1S5		150	
#define 	TIME10MS_2S			200	
#define 	TIME10MS_2S5		250	
#define 	TIME10MS_3S			300	
#define 	TIME10MS_3S5		350
#define 	TIME10MS_5S			500
#define 	TIME100MS_1S		10	
#define 	TIME100MS_1S5		15
#define 	TIME100MS_2S		20
#define 	TIME100MS_2S5		25
#define 	TIME100MS_3S		30
#define 	TIME100MS_3S5		35
#define 	TIME100MS_5S		50
#define 	TIME100MS_6S		60
#define 	TIME100MS_8S		80
#define 	TIME100MS_60S		600



/*! 
*  \brief  I/O function define
*/
#define 	KEY_ON 				GPIO_PIN_RESET
#define 	KEY_OFF				GPIO_PIN_SET

//#define 	ON 					GPIO_PIN_SET
//#define 	OFF 				GPIO_PIN_RESET
#define 	HIGH 				GPIO_PIN_SET
#define 	LOW 				GPIO_PIN_RESET

#define 	SEG_ON 				GPIO_PIN_RESET
#define 	SEG_OFF 			GPIO_PIN_SET

#define 	DIG_ON 				GPIO_PIN_RESET
#define 	DIG_OFF 			GPIO_PIN_SET


/*! 
*  \brief  macro define
*/
//INPUT pot

#define 	KEY_UP			HAL_GPIO_ReadPin(KEY2_GPIO_Port,KEY2_Pin)
#define 	KEY_DOWN		HAL_GPIO_ReadPin(KEY5_GPIO_Port,KEY5_Pin)
#define 	KEY_LEFT		HAL_GPIO_ReadPin(KEY3_GPIO_Port,KEY3_Pin)
#define 	KEY_RIGHT		HAL_GPIO_ReadPin(KEY1_GPIO_Port,KEY1_Pin)
#define 	KEY_ENTER		HAL_GPIO_ReadPin(KEY4_GPIO_Port,KEY4_Pin)


//OUTPUT port

#define 	LCD_BACK_ON			HAL_GPIO_WritePin(PWM_BLACK_GPIO_Port, PWM_BLACK_Pin, HIGH)
#define 	LCD_BACK_OFF		HAL_GPIO_WritePin(PWM_BLACK_GPIO_Port, PWM_BLACK_Pin, LOW)
#define 	LCD_BACK_TOGGLE		HAL_GPIO_TogglePin(PWM_BLACK_GPIO_Port, PWM_BLACK_Pin)

#define 	LCD_NSS_ENA			HAL_GPIO_WritePin(SPI1_NSS_GPIO_Port, SPI1_NSS_Pin, LOW)
#define 	LCD_NSS_DISA		HAL_GPIO_WritePin(SPI1_NSS_GPIO_Port, SPI1_NSS_Pin, HIGH)

#define 	LCD_WRX_CLR			HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, LOW)
#define 	LCD_WRX_SET			HAL_GPIO_WritePin(SPI1_SS_GPIO_Port, SPI1_SS_Pin, HIGH)

#define 	LCD_RST_CLR			HAL_GPIO_WritePin(RESET_TFT_GPIO_Port, RESET_TFT_Pin, LOW)
#define 	LCD_RST_SET			HAL_GPIO_WritePin(RESET_TFT_GPIO_Port, RESET_TFT_Pin, HIGH)

#define 	BEEP_ON				HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, HIGH)
#define 	BEEP_OFF			HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, LOW)
#define 	BEEP_TOGGLE			HAL_GPIO_TogglePin(BEEP_GPIO_Port, BEEP_Pin)


//HAL_GPIO_TogglePin(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
//#define 	DIG1_TOGGLE			HAL_GPIO_TogglePin(DT_DIG1_GPIO_Port, DT_DIG1_Pin)



/*! 
*  \brief  system model macro define
*/
#define 	STANDBY 	0X00
#define 	MODEL1 		0X01
#define 	MODEL2 		0X02
#define 	PASSWORD 	0X08



/*! 
*  \brief  variable definition, extern
*  \param  外部调用
*/

//
//extern	uint8_t	u8SystemErrorFlag;
//extern	uint8_t	toggle;

//extern	uint8_t u8Flag_System;
//extern	uint8_t	u8Flag_PowerUp;

//*CONTROL*/


//*UI*/



/**
  * @}
*/ 

#endif /* __user_H */
/***************** (C) COPYRIGHT LYC ********** END OF FILE ******************/

